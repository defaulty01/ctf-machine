# WEB CTF MACHINE

Welcome players,

There are 6 flags in this challenge. Grab as much as you want..
I'm not expecting you to get user/root flag coz I run out of ideas..

Note: UI is not much and I hope you'll enjoy the challenge.

To setup:
  1. Download and setup ubuntu-20.04.3-live-server-amd64.
  2. Navigate to setup folder. Run setup.sh as root.
  3. That's it. Enjoy :D


To do:
  * Make a way players can elevate privileges.
  * Create user privesc
  * Create root privesc
