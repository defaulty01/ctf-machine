<?php

define(FLAG, "");



